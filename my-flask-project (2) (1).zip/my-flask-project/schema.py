from ariadne import gql
from ariadne import QueryType, MutationType

type_defs = gql("""
    # Define your GraphQL types and schema here
    type Query {
        CustomWelcome: String
    }

    type Mutation {
        Updatewelcome(name: String!): String
    }
""")

query = QueryType()
mutation = MutationType()

@query.field("CustomWelcome")
def resolve_hello(_, info):
    return "Welcome to my app!"

@mutation.field("UpdateWelcome")
def resolve_say_hello(_, info, name):
    return f"Hello, {name}!Your greeting has been updated."



schema = [type_defs, query, mutation]
