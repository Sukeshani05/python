from flask import Flask, request, jsonify
from ariadne import make_executable_schema
from ariadne.asgi import GraphQL

# Import  query and mutation 
from schema import type_defs, query, mutation

# Creating an executable for GraphQL schema
schema = make_executable_schema(type_defs, query, mutation)

app = Flask(__name__)

# here i'm creating custom view function to handle GraphQL requests
@app.route('/graphql', methods=['POST'])
def graphql_view():
    data = request.get_json()
    success, result = GraphQL(schema, debug=True).execute(data)
    status_code = 200 if success else 400
    return jsonify(result), status_code

if __name__ == '__main__':
    app.run()

