import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import { ApolloProvider } from "@apollo/client";
import { gql } from "@apollo/client";
import Keycloak from "@keycloak/keycloak-js";
import keycloakAuthz from "keycloak-authz-middleware";
import Stripe from "stripe";
return (
    <div>
      {isUserLoggedIn ? (
        <h1>Welcome, {user.username}</h1>
      ) : (
        <h1>Please login</h1>
      )}
  
      <h2>Todos</h2>
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            <h3>{todo.title}</h3>
            <p>{todo.description}</p>
            <p>{todo.time}</p>
            <ul>
              {todo.images.map((image) => (
                <li key={image.id}>
                  <img src={image.url} alt="Todo Image" />
                </li>
              ))}
            </ul>
            <button onClick={() => handleDeleteTodolist(todo.id)}>Delete</button>
            <button onClick={() => handleEditTodolist(todo.id)}>Edit</button>
            {licenseStatus === "Pro" ? (
              <button onClick={() => handleUploadImage(todo.id, image)}>Upload Image</button>
            ) : null}
          </li>
        ))}
      </ul>
      <button onClick={handleAddTodolist}>Add Todo</button>
    </div>
  );
  const handleAddTodolist = () => {
    const newTodo = {
      id: todos.length + 1,
      title: "",
      description: "",
      time: "",
      images: [],
    };
  
    setTodos([...todos, newTodo]);
  };
  
  const handleDeleteTodolist = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };
  
  const handleEditTodolist = (id) => {
    const newTodolist = {
      id,
      title: "",
      description: "",
      time: "",
      images: [],
    };
  
    setTodos([...todos.filter((todo) => todo.id !== id), newTodolist]);
  };
  
  const handleUploadImage = (id, image) => {
    if (licenseStatus !== "Pro") {
      return;
    }
  
    const newTodo = {
      id,
      title: todos[id].title,
      description: todos[id].description,
      time: todos[id].time,
      images: [...todos[id].images, image],
    };
  
    setTodos([...todos.filter((todo) => todo.id !== id), newTodo]);
  };
    