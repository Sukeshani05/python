from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base


Base = declarative_base()

# Define the To-Do model
class TodoList(Base):
    __tablename__ = 'todosList'

    id = Column(Integer, primary_key=True)
    title = Column(String(255))
    description = Column(String(255))
    time = Column(DateTime)
    images = relationship('picture', secondary='todoList_picture')


class Image(Base):
    __tablename__ = 'picture'

    id = Column(Integer, primary_key=True)
    filename = Column(String(255))


todolist_images = Table('todolist_picture', Base.metadata,
    Column('todo_id', Integer, ForeignKey('todosList.id')),
    Column('image_id', Integer, ForeignKey('picture.id'))
)

engine = create_engine('sqlite:///your_database_file.db')  

Base.metadata.create_all(engine)
